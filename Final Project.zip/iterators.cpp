//The program below takes the id of a student and either sets or displays the 		students name
#include <iostream>
#include <map>
#include <string>

int main()
{
	//test data
	std::map<int,std::string> Students = {{88089,"Kelly Mulumbi"}, {87655,"Tevin Mutarura"}};

	char choice;
	int stdId;
	std::string name;
	std::cout	<<"->>----------Select an Option----------<<-"
				<<std::endl
				<<"\t a)\t Create a new record"
				<<std::endl
				<<"\t b)\t Search for a record"
				<<std::endl;
	std::cin >> choice;
	if(choice == 'a' || choice == 'A'){
		std::cout	<<"Enter student number:"
					<< std::endl;
		std::cin	>> stdId;
			
		//Check if the admission number already exists
		auto search = Students.find(stdId);
		if(search != Students.end())
			std::cout 	<< "Admission Number = " << search->first
						<< " already exists. Try Again"
						<<std::endl;
		else{
			std::cout	<<"Enter student name:"
					<< std::endl;
			std::cin	>> name;
			
			//Insert new record into the container
			Students[stdId] = name;
			std::cout	<<"The following record has been added into the container"
						<<std::endl;
			//Search for the admission number in the map
			auto search = Students.find(stdId);
			if(search != Students.end())
				std::cout 	<< "Found Admission Number = " << search->first
							<< std::endl
							<< "Name = "    << search->second  
							<< std::endl;
		}
	}
		
	else if(choice == 'b' || choice == 'B'){
		std::cout	<< "Enter the admission number you wish to search 	for:"
					<<std::endl;
		std::cin	>> stdId;
		
		//Search for the admission number in the map
		auto search = Students.find(stdId);
		if(search != Students.end())
			std::cout 	<< "Found Admission Number = " << search->first
						<< std::endl
						<< "Name = "    << search->second  
						<< std::endl;
		else
			std::cout << "That student ID was not found\n";
	}
}
	

