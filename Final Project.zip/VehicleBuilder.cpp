#include <string>
#include <vector>
#include <map>
#include <cassert> //assert()

class VehiclePart{

	public: 
		enum VPart{ENGINE,STEERINGWHEEL,HOOD,BOOT,PETROLTANK,CARRIER,SUNROOF,WIPER,NPARTS};
		VehiclePart(VPart id):id(id){}
		friend std::ostream&
		operator<<(std::ostream&,const VehiclePart&);
	
	private:
		static std::string parts[NPARTS];
		VPart id;
		
};

std::string VehiclePart::parts[NPARTS]={"Engine","Steeringwheel","Hood","Boot","Petroltank","Carrier","Sunroof","Wiper"};
std::ostream&
operator<<(std::ostream& out, const VehiclePart& vehicle){
	return out<<vehicle.parts[vehicle.id];
}

class Vehicle{
		std::vector<VehiclePart*> parts;
	public:
		~Vehicle();
		void addPart(VehiclePart* part){parts.push_back(part);}
		friend std::ostream&
		operator<<(std::ostream&, const Vehicle&);
};
 
std::ostream&
operator<<(std::ostream& out, const Vehicle& vehicle){
	out << "has [";
	for(auto part: vehicle.parts) out<<(*part)<< '  ' ;
	return out << ']';
}

class VehicleBuilder{
	
	public: 
		Vehicle* vehicle;
		VehicleBuilder(): vehicle(0){}
		void createVehicle(){vehicle= new Vehicle;}
		
		virtual void buildEngine()=0;
		virtual void buildSteeringwheel()=0;
		virtual void buildHood()=0;
		virtual void buildBoot()=0;
		virtual void buildPetroltank()=0;
		virtual void buildCarrier()=0;
		virtual void buildSunroof()=0;
		virtual void buildWiper()=0;
		virtual std::string getVehicleName() const = 0;
Vehicle* getVehicle(){
	Vehicle* newVehicle=vehicle;
	vehicle=0;
	return newVehicle;
	}
};

class SedanBuilder: public VehicleBuilder{
	public:
		void buildEngine(){
			vehicle->addPart(new VehiclePart(VehiclePart::ENGINE));
		}
		void buildSteeringwheel(){
			vehicle->addPart(new VehiclePart(VehiclePart::STEERINGWHEEL));
		}
		void buildHood(){
			vehicle->addPart(new VehiclePart(VehiclePart::HOOD));
		}
		void buildBoot(){
			vehicle->addPart(new VehiclePart(VehiclePart::BOOT));
		}
		void buildPetroltank(){
			vehicle->addPart(new VehiclePart(VehiclePart::PETROLTANK));
			
		}
		void buildCarrier(){}
		void buildSunroof(){}
		void buildWiper(){
			vehicle->addPart(new VehiclePart(VehiclePart::WIPER));
		}
		std::string getVehicleName(){
			return "Sedan";
		}
};

class TruckBuilder: public VehicleBuilder{
	public:
		void buildEngine(){
			vehicle->addPart(new VehiclePart(VehiclePart::ENGINE));
		}
		void buildSteeringwheel(){
			vehicle->addPart(new VehiclePart(VehiclePart::STEERINGWHEEL));
		}
		void buildHood(){
			vehicle->addPart(new VehiclePart(VehiclePart::HOOD));
		}
		void buildBoot(){
			vehicle->addPart(new VehiclePart(VehiclePart::BOOT));
		}
		void buildPetroltank(){
			vehicle->addPart(new VehiclePart(VehiclePart::PETROLTANK));
			
		}
		void buildCarrier(){
			vehicle->addPart(new VehiclePart(VehiclePart::CARRIER));
		}
		void buildSunroof(){}
		void buildWiper(){
			vehicle->addPart(new VehiclePart(VehiclePart::WIPER));
		}
		std::string getVehicleName(){
			return "Truck";
		}
};

class ConvertibleBuilder: public VehicleBuilder{
	public:
		void buildEngine(){
			vehicle->addPart(new VehiclePart(VehiclePart::ENGINE));
		}
		void buildSteeringwheel(){
			vehicle->addPart(new VehiclePart(VehiclePart::STEERINGWHEEL));
		}
		void buildHood(){
			vehicle->addPart(new VehiclePart(VehiclePart::HOOD));
		}
		void buildBoot(){
			vehicle->addPart(new VehiclePart(VehiclePart::BOOT));
		}
		void buildPetroltank(){
			vehicle->addPart(new VehiclePart(VehiclePart::PETROLTANK));
			
		}
		void buildCarrier(){
			vehicle->addPart(new VehiclePart(VehiclePart::CARRIER));
		}
		void buildSunroof(){
			vehicle->addPart(new VehiclePart(VehiclePart::SUNROOF));
		}
		void buildWiper(){
			vehicle->addPart(new VehiclePart(VehiclePart::WIPER));
		}
		std::string getVehicleName(){
			return "Convertible";
		}
};

class Mechanic{
	
	VehicleBuilder* builder;
public:
	Mechanic():builder(0){}
	void setbuilder(VehicleBuilder* builder){
		this->builder = builder;
	}
	void make(){
		assert(builder);
		builder->createVehicle();
		builder->createEngine();
		builder->createSteeringwheel();
		builder->createHood();
		builder->createBoot();
		builder->createPetroltank();
		builder->createCarrier();
		builder->createSunroof();
		builder->createWiper();
	}
};

using namespace std;
Vehicle*
makeAVehicle(Mechanic& mechanic, VehicleBuilder* pattern){
	mechanic.setBuilder(pattern);
	mechanic.make();
	Vehicle* vehicle=pattern->getVehicle();
	cout<< "The Mechanic made a" <<pattern->getVehicleName()<<endl;
	return vehicle;
}

int main(){
	map<string, int> garage;
	garage["sedans"]=5;
	garage["trucks"]=4;
	garage["convertibles"]=2;
	
	vector<Vehicle*> containers;
	SedanBuilder* sb = new SedanBuilder;
	TruckBuilder* tb = new TruckBuilder;
	ConvertibleBuilder* cb = new ConvertibleBuilder;
	
	Mechanic mechanic;
	map<string, int>::const_iterator cit = garage.begin();
	while(cit!=garage.end()){
		VehicleBuilder* pattern;
		if(cit->first == "sedans")
			pattern = sb;
		else if (cit->first == "trucks")
			pattern = tb;
		else if (cit->first == "convertibles")
			pattern = cb;
		for(int=0; i <cit->second; ++i)
			containers.push_back(makeAVehicle(mechanic, pattern));
			++cit;
	}
	delete sb;
	delete tb;
	delete cb;
	int i=0;
	for(auto container: containers)
		cout << "Container " << i++
			 << " " <<(*container) << endl;
}
