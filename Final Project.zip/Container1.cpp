#include <iostream>
#include <string>
#include <map>
#include <iterator>

using namespace std;
int main(){
    std::map<string, int> words;
   const string endmark("***");
    cout << "Enter some text. Type \"" << endmark << "\" to end." << endl;
    std::istream_iterator<string> begin(cin);
    std::istream_iterator<string> end;
    while(begin != end){
        if(*begin == endmark)
            break;
    words[*begin++]++;
}

    for(std::map<string,int>::iterator iter = words.begin(); iter != words.end(); ++iter)
        cout << iter->second << " " << iter->first << endl;

return 0;
}

