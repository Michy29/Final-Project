#include <iostream>
#include <vector>

using namespace std;

int main(void)
{

vector <int> iVektor;
do
{
cout<<"Next Element->";
int iElement;
cin>>iElement;
iVektor.push_back(iElement);
cout<<"Size of the vector is ="<<iVektor.size()<<endl
    <<"Capacity of the vector="<<iVektor.capacity()<<endl;

cout<<"More elements yes(y)/no(n)->";
char cRespond; cin>>cRespond;

if((cRespond == 'y')||(cRespond=='Y')) continue;
    break;

} while(true);
for(vector<int>::iterator i=iVektor.begin();
    i != iVektor.end();
    cout<<*i++<<endl); cout<<endl<<endl;

cout<<"You wish to see the element->";
int iIndex;
cin>>iIndex;

cout<<"At("<<iIndex<<")="
    <<iVektor.at(iIndex)<<endl
    <<"or like this=";

return 0;

}
